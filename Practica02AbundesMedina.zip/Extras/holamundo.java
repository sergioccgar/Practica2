/**
 * holamundo
 */
public class holamundo {
    public static void main(String[] args) {
        System.out.println("Hola Mundo");
    }
    
}
public class ciclosComplejidad {
    public static void main(String[] args) {
        System.out.println("Hola");

        int j = 0;

        // j = 0;
        System.out.println(j++);
        //j = 1;
        
        System.out.println(j);

        //j = 2;
        System.out.println(++j);
        //j = 2;
        
        
        System.out.println("############");
        int k = 0;

        while(++k < 10){
            System.out.println(k);
        }

        System.out.println("############");
        int n = 10;

        for (int i = 0; i < n; ++i) {
            System.out.println(i);
        }
        
        
        n = 3
        i = 0

        0 < 3 
        print 
        incremento -> i = 1
        
        1 < 3 
        print 
        incremento -> i = 2
        
        2 < 3 
        print 
        incremento -> i = 3
        
        3 < 3 
        .

        i<=n -> n+1
        i < n -> n+2


        int n = 2;
        for (int i = 0; i < n; i++) {
            for (int l = 0; l < n; l++) {
                System.out.println(i);
            }
            
        }
        
        n = 2
        i = 0
        l = 0

        i < 2 
            l < 2 
                print 
                incremento -> l = 1
            l < 2 
                print 
            incremento -> l = 2
            l < 2 


        incremento -> i = 1
        
        i < 2 
            l = 0
            l < 2 
                print 
                incremento -> l = 1
            l < 2 
                print 
            incremento -> l = 2
            l < 2 
        
        i < 2 

                
        
        
















    }
}

Práctica02 de Estructuras de Datos.
Irving Miguel Abundes Gutiérrez 319236170
Sergio Medina Guzmán 314332428
